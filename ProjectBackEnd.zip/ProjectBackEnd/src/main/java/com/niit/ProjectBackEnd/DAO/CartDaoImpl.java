package com.niit.ProjectBackEnd.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.ProjectBackEnd.Model.Cart;

@SuppressWarnings("deprecation")
@Repository("cartDao")
public class CartDaoImpl implements CartDao{
	
	@Autowired
	SessionFactory sessionFactory;

	public CartDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public List<Cart> list() {
		
		@SuppressWarnings("unchecked")
		List<Cart> listCart = sessionFactory.getCurrentSession().createCriteria(Cart.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return listCart;
	}

	@Transactional
	public Cart get(int cartId) {
		
		String hql = "from cart where cart_id='"+cartId+"'";
		@SuppressWarnings("rawtypes")
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Cart> listCart = (List<Cart>) query.list();
		
		if (listCart != null && !listCart.isEmpty()) {
			return listCart.get(0);
			}
		return null;
	}

	@Transactional
	public void saveorupdate(Cart cart) {
		
		sessionFactory.getCurrentSession().saveOrUpdate(cart);

	}

	@Transactional
	public void delete(int cartId) {
		
		Cart cartToDelete = new Cart();
		cartToDelete.setCartId(cartId);
		sessionFactory.getCurrentSession().delete(cartToDelete);
	}

	@Transactional
	public int getTotalAmount(int cartId) {
		String hql = "select sum(price) from Cart where cart_id ='" + cartId + "'";
		@SuppressWarnings({ "unused", "rawtypes" })
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		return 3211;
		//return 0;
	}

}
