package com.niit.ProjectBackEnd.DAO;

import java.util.List;

import com.niit.ProjectBackEnd.Model.Product;

public interface ProductDao {
	
	public List<Product> list();
	
	public Product get(String productId);
	
	
	public void saveorupdate(Product product);
	
	public void delete(String productId);

}
