package com.niit.ProjectBackEnd.Config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.niit.ProjectBackEnd.DAO.CartDao;
import com.niit.ProjectBackEnd.DAO.CartDaoImpl;
import com.niit.ProjectBackEnd.DAO.CategoryDao;
import com.niit.ProjectBackEnd.DAO.CategoryDaoImpl;
import com.niit.ProjectBackEnd.DAO.ProductDao;
import com.niit.ProjectBackEnd.DAO.ProductDaoImpl;
import com.niit.ProjectBackEnd.DAO.SupplierDao;
import com.niit.ProjectBackEnd.DAO.SupplierDaoImpl;
import com.niit.ProjectBackEnd.DAO.UserDao;
import com.niit.ProjectBackEnd.DAO.UserDaoImpl;
import com.niit.ProjectBackEnd.Model.Cart;
import com.niit.ProjectBackEnd.Model.Category;
import com.niit.ProjectBackEnd.Model.Product;
import com.niit.ProjectBackEnd.Model.Supplier;
import com.niit.ProjectBackEnd.Model.User;

@Configuration
@ComponentScan("com.niit.ProjectBackEnd")
@EnableTransactionManagement

public class AppContextConfiguration {
	
	@Bean(name = "dataSource")
	public DataSource getDataSource() {
    	DriverManagerDataSource dataSource = new DriverManagerDataSource();
    	dataSource.setDriverClassName("org.h2.Driver");
    	dataSource.setUrl("jdbc:h2:tcp://localhost/~/test");
    	dataSource.setUsername("sa");
    	dataSource.setPassword("");
    	
    	return dataSource;
    }
	
	
	private Properties getHibernateProperties()
	{
		Properties properties=new Properties();
		properties.put("hibernate.show_sql", "true");
		properties.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
		properties.put("hbm2ddl.auto","create");
		
		return properties;
	}
	
	
	@Autowired
	@Bean(name="sessionFactory")
	public SessionFactory getSessionFactory(DataSource dataSource) 
	{
    	LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
    	sessionBuilder.addProperties(getHibernateProperties());
    	sessionBuilder.addAnnotatedClasses(User.class);
    	sessionBuilder.addAnnotatedClasses(Category.class);
    	sessionBuilder.addAnnotatedClasses(Product.class);
    	sessionBuilder.addAnnotatedClasses(Supplier.class);
    	sessionBuilder.addAnnotatedClasses(Cart.class);
  
    	return sessionBuilder.buildSessionFactory();
    }
	
	
	@Autowired
	@Bean(name = "transactionManager")
	public HibernateTransactionManager getTransactionManager(SessionFactory sessionFactory)
	{
		HibernateTransactionManager transactionManager = new HibernateTransactionManager(
				sessionFactory);

		return transactionManager;
	}
	
	@Autowired
    @Bean(name = "userDao")
    public UserDao getUserDao(SessionFactory sessionFactory) 
	{
    	return new UserDaoImpl(sessionFactory);
    }
	
	@Autowired
    @Bean(name = "categoryDao")
    public CategoryDao getCategoryDao(SessionFactory sessionFactory) 
	{
    	return new CategoryDaoImpl(sessionFactory);
    }
	
	@Autowired
    @Bean(name = "productDao")
    public ProductDao getProductDao(SessionFactory sessionFactory) 
	{
    	return new ProductDaoImpl(sessionFactory);
    }

	@Autowired
    @Bean(name = "supplierDao")
    public SupplierDao getSupplierDao(SessionFactory sessionFactory) 
	{
    	return new SupplierDaoImpl(sessionFactory);
    }
	
	@Autowired
    @Bean(name = "cartDao")
    public CartDao getCartDao(SessionFactory sessionFactory) 
	{
    	return new CartDaoImpl(sessionFactory);
    }
	

}
