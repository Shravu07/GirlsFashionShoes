package com.niit.ProjectBackEnd.DAO;

import java.util.List;

import com.niit.ProjectBackEnd.Model.Category;

public interface CategoryDao {
	
public List<Category> list();
	
	public Category get(String categoryId);
	
	public void saveorupdate(Category category);
	
	public void delete(String categoryId);
	
	public Category getByName(String categoryName);


}
