package com.niit.ProjectBackEnd.DAO;

import java.util.List;

import com.niit.ProjectBackEnd.Model.Cart;

public interface CartDao {
	
public List<Cart> list();
	
	public Cart get(int cartId);
	
	public void saveorupdate(Cart cart);
	
	public void delete(int cartId);
	
	public int getTotalAmount(int cartId);

}
