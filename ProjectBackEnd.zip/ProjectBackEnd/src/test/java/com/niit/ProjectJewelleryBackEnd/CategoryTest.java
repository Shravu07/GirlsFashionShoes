package com.niit.ProjectJewelleryBackEnd;

public class CategoryTest {

	public static void main(String[] args) {
		

	}

}
