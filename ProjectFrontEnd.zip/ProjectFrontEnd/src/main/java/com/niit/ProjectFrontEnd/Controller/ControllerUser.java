package com.niit.ProjectFrontEnd.Controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.ProjectBackEnd.DAO.CategoryDao;
import com.niit.ProjectBackEnd.DAO.UserDao;
import com.niit.ProjectBackEnd.Model.Category;
import com.niit.ProjectBackEnd.Model.User;

@Controller
public class ControllerUser {
	
	
	@Autowired
	UserDao userDAO;
	
	@Autowired
	User user;
	
	@Autowired
	CategoryDao categoryDao;
	
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public ModelAndView printWelcome(Principal principal, HttpServletRequest request) 
	{
		ModelAndView mv;
		String userId = principal.getName();
		System.out.println(userId);
		if (request.isUserInRole("ROLE_ADMIN")) {
			System.out.println(request.isUserInRole("ROLE_ADMIN"));
			System.out.println("Admin page");
			mv=new ModelAndView("adminpage");
			mv.addObject("isAdminpage", true);
			mv.addObject("userId", userId);
			return mv;
	} 
		
		else {
			System.out.println(request.isUserInRole("ROLE_USER"));
			System.out.println("user page");
			mv=new ModelAndView("helloUser");
			mv.addObject("username", userId);
			mv.addObject("category", new Category());
			mv.addObject("categoryList", this.categoryDao.list());
			mv.addObject("isUserHome", true);
			return mv;
		}
	}

}
