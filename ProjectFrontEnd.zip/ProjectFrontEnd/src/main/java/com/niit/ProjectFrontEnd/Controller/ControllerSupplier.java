package com.niit.ProjectFrontEnd.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.ProjectBackEnd.DAO.SupplierDao;
import com.niit.ProjectBackEnd.Model.Supplier;

@Controller
public class ControllerSupplier {
	
	@Autowired
	SupplierDao supplierDao;
	
	@RequestMapping(value ="/getsuppliers", method = RequestMethod.GET)
	public String listSupplier(Model model) {
	{
		
		model.addAttribute("supplier", new Supplier());
		model.addAttribute("supplierList", this.supplierDao.list());
		model.addAttribute("isSupplierClicked", true);
		return "adminpage";
	}
	}
	
	
	@RequestMapping(value = "/supplier/add", method = RequestMethod.POST)
	public String addSupplier(@ModelAttribute("supplier") Supplier supplier)
	{
		supplierDao.saveorupdate(supplier);
		return "redirect:/getsuppliers";
	}
	
	
	@RequestMapping("supplier/remove/{supplierId}")
	public String removeSupplier(@PathVariable("supplierId") String supplierId, ModelMap model) throws Exception
    {
    	try 
    	{
			supplierDao.delete(supplierId);
			model.addAttribute("message", "Successfully Added");
		} 
    	
    	catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}
		
		return "redirect:/getsuppliers";
	}
	
	
	@RequestMapping("supplier/edit/{supplierId}")
	public String editSupplier(@PathVariable("supplierId") String supplierId, Model model)
	{
		System.out.println("editSupplier");
        model.addAttribute("supplier", this.supplierDao.get(supplierId));
        model.addAttribute("listSupplier", this.supplierDao.list());
        model.addAttribute("isSupplierClicked", true);
        return "adminpage";
	}
	
	
	

}
