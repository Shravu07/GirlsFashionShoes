package com.niit.ProjectFrontEnd.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.ProjectBackEnd.DAO.CategoryDao;
import com.niit.ProjectBackEnd.DAO.UserDao;
import com.niit.ProjectBackEnd.Model.Category;
import com.niit.ProjectBackEnd.Model.User;

@Controller
public class HomepageController {
	
	@Autowired
	CategoryDao categoryDao;

	@Autowired
	UserDao userDao;

	@Autowired
	User user;
	
	@RequestMapping("/")
	public ModelAndView getLanding() {
		ModelAndView mv = new ModelAndView("home");
		return mv;
	}
	
	@RequestMapping("/home")
	public ModelAndView getHome() {
		ModelAndView mv = new ModelAndView("home");
		return mv;
	}
	
	@RequestMapping("/aboutus")
	public ModelAndView getaboutus()
	{
		ModelAndView aboutus=new ModelAndView("aboutus");
		return aboutus;
	}
	
	
	@RequestMapping("/contactus")
	public ModelAndView getcontactus()
	{
		ModelAndView contactus=new ModelAndView("contactus");
		return contactus;
	}

	
	
	@RequestMapping("/products")
	public ModelAndView getproducts()
	{
		ModelAndView products=new ModelAndView("products");
		return products;
	}
	
	
		
	
	@RequestMapping("/login")
	public ModelAndView getLogin()
	{
		ModelAndView login=new ModelAndView("login");
		return login;
	}
	
	@RequestMapping("/signup")
	public ModelAndView getSignup()
	{
		ModelAndView signup=new ModelAndView("signup");
		return signup;
	}
	
	
	

}
